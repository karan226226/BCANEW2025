import './App.css';
import { RouterProvider, createBrowserRouter } from 'react-router-dom';
import Home from './components/Home/Home';
import User from './components/getuser/User';
import Navbar from './components/Navbar/Navbar';
import Add from './components/adduser/Add'; // Import the Add component
import Edit from './components/updateuser/Edit'; // Import the Edit component

function App() {
  const route = createBrowserRouter([
    {
      path: '/',
      element: (
        <>
          <Navbar />
          <Home />
        </>
      ),
    },
    {
      path: '/museums',
      element: (
        <>
          <Navbar />
          <User />
        </>
      ),
    },
    {
      path: '/add',
      element: (
        <>
          <Navbar />
          <Add />
        </>
      ),
    },
    {
      path: '/edit/:id',
      element: (
        <>
          <Navbar />
          <Edit />
        </>
      ),
    },
  ]);

  return (
    <div className="App">
      <RouterProvider router={route} />
    </div>
  );
}

export default App;
