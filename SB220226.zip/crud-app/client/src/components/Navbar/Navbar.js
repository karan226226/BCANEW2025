import React from 'react';
import { Link } from 'react-router-dom';
import './Navbar.css';

const Navbar = () => {
  return (
    <nav className="navbar">
      <div className="navbarContainer">
        <Link to="/" className="navbarLogo">
          Museum Explorer
        </Link>
        <div className="navbarLinks">
          <Link to="/" className="navbarLink">
            Home
          </Link>
          <Link to="/museums" className="navbarLink">
            Explore
          </Link>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;