import React from 'react';
import { Link } from 'react-router-dom';
import './Home.css';

const Home = () => {
  return (
    <div className="homeContainer">
      {/* Hero Section */}
      <div className="heroSection">
        <h1>Welcome to Museum Explorer</h1>
        <p>Discover the world's most fascinating museums and their stories.</p>
        <Link to="/museums" className="exploreButton">
          Explore Museums
        </Link>
      </div>

      {/* Agenda Section */}
      <div className="agendaSection">
        <h2>Our Agenda</h2>
        <p>
          We aim to provide a platform where you can explore, learn, and
          appreciate the rich history and culture preserved in museums around the
          world.
        </p>
      </div>

      {/* Featured Museums Section */}
      <div className="featuredSection">
        <h2>Featured Museums</h2>
        <div className="museumGrid">
          <div className="museumCard">
            <img
              src="https://images.unsplash.com/photo-1575503802870-45de6a6217c8?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80"
              alt="Louvre Museum"
            />
            <h3>Louvre Museum</h3>
            <p>Paris, France</p>
          </div>
          <div className="museumCard">
            <img
              src="https://images.unsplash.com/photo-1584977388609-c20761b6f96c?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80"
              alt="British Museum"
            />
            <h3>British Museum</h3>
            <p>London, UK</p>
          </div>
          <div className="museumCard">
            <img
              src="https://images.unsplash.com/photo-1581617468627-89f9f2b2a4d6?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80"
              alt="Metropolitan Museum of Art"
            />
            <h3>Metropolitan Museum of Art</h3>
            <p>New York, USA</p>
          </div>
        </div>
      </div>

      {/* Upcoming Events Section */}
      <div className="eventsSection">
        <h2>Upcoming Events</h2>
        <div className="eventList">
          <div className="eventCard">
            <h3>Art Through the Ages</h3>
            <p>Date: October 15, 2023</p>
            <p>Location: Louvre Museum, Paris</p>
          </div>
          <div className="eventCard">
            <h3>Ancient Civilizations Exhibition</h3>
            <p>Date: November 5, 2023</p>
            <p>Location: British Museum, London</p>
          </div>
          <div className="eventCard">
            <h3>Modern Art Showcase</h3>
            <p>Date: December 10, 2023</p>
            <p>Location: Metropolitan Museum of Art, New York</p>
          </div>
        </div>
      </div>

      {/* Testimonials Section */}
      <div className="testimonialsSection">
        <h2>What Our Visitors Say</h2>
        <div className="testimonialList">
          <div className="testimonialCard">
            <p>
              "Museum Explorer made it so easy to discover new museums and plan
              my visits. Highly recommended!"
            </p>
            <p>- Sarah L.</p>
          </div>
          <div className="testimonialCard">
            <p>
              "The detailed information and beautiful visuals on this platform
              are amazing. It's like a virtual tour!"
            </p>
            <p>- John D.</p>
          </div>
          <div className="testimonialCard">
            <p>
              "I love the upcoming events section. It helps me stay updated on
              what's happening in the museum world."
            </p>
            <p>- Emily R.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;