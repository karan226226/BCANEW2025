import React, { useEffect, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom';
import axios from "axios";
import "../adduser/add.css";
import toast from 'react-hot-toast';

const Edit = () => {

 const museum = {
    museum_name: "",
    location: "",
    museum_type: "",
    museum_fee: ""
 }

 const {id} = useParams();
 const navigate = useNavigate();
 const [museumData, setMuseumData] = useState(museum);

 const inputChangeHandler = (e) =>{
    const {name, value} = e.target;
    setMuseumData({...museumData, [name]:value});
 }

 useEffect(()=>{
    axios.get(`http://localhost:8000/api/getone/${id}`)
    .then((response)=>{
        setMuseumData(response.data)
    })
    .catch((error)=>{
        console.log(error);
    })
 },[id])

 const submitForm = async(e)=>{
    e.preventDefault();
    await axios.put(`http://localhost:8000/api/update/${id}`, museumData)
    .then((response)=>{
       toast.success(response.data.msg, {position:"top-right"})
       navigate("/")
    })
    .catch(error => console.log(error))
 }

  return (
    <div className='addUser'>
        <Link to={"/"}>Back</Link>
        <h3>Update Museum</h3>
        <form className='addUserForm' onSubmit={submitForm}>
            <div className="inputGroup">
                <label htmlFor="museum_name">Museum Name</label>
                <input type="text" value={museumData.museum_name} onChange={inputChangeHandler} id="museum_name" name="museum_name" autoComplete='off' />
            </div>
            <div className="inputGroup">
                <label htmlFor="location">Location</label>
                <input type="text" value={museumData.location} onChange={inputChangeHandler} id="location" name="location" autoComplete='off' />
            </div>
            <div className="inputGroup">
                <label htmlFor="museum_type">Type</label>
                <input type="text" value={museumData.museum_type} onChange={inputChangeHandler} id="museum_type" name="museum_type" autoComplete='off' />
            </div>
            <div className="inputGroup">
                <label htmlFor="museum_fee">Entry Fee</label>
                <input type="number" value={museumData.museum_fee} onChange={inputChangeHandler} id="museum_fee" name="museum_fee" autoComplete='off' />
            </div>
            <div className="inputGroup">
                <button type="submit">UPDATE MUSEUM</button>
            </div>
        </form>
    </div>
  )
}

export default Edit