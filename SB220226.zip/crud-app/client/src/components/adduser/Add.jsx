import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom';
import axios from "axios";
import "./add.css";
import toast from 'react-hot-toast';

const Add = () => {

  const museum = {
    museum_name:"",
    location:"",
    museum_type:"",
    museum_fee:""
  }

  const [museumData, setMuseumData] = useState(museum);
  const navigate = useNavigate();

  const inputHandler = (e) =>{
      const {name, value} = e.target;
      setMuseumData({...museumData, [name]:value});
  }

  const submitForm = async(e) =>{
    e.preventDefault();
    await axios.post("http://localhost:8000/api/create", museumData)
    .then((response)=>{
       toast.success(response.data.msg, {position:"top-right"})
       navigate("/museums")
    })
    .catch(error => console.log(error))
  }

  return (
    <div className='addUser'>
        <Link to={"/"}>Back</Link>
        <h3>Add new museum</h3>
        <form className='addUserForm' onSubmit={submitForm}>
            <div className="inputGroup">
                <label htmlFor="museum_name">Museum Name</label>
                <input type="text" onChange={inputHandler} id="museum_name" name="museum_name" autoComplete='off' placeholder='Museum name' />
            </div>
            <div className="inputGroup">
                <label htmlFor="location">Location</label>
                <input type="text" onChange={inputHandler} id="location" name="location" autoComplete='off' placeholder='Location' />
            </div>
            <div className="inputGroup">
                <label htmlFor="museum_type">Type</label>
                <input type="text" onChange={inputHandler} id="museum_type" name="museum_type" autoComplete='off' placeholder='Museum type' />
            </div>
            <div className="inputGroup">
                <label htmlFor="museum_fee">Entry Fee</label>
                <input type="number" onChange={inputHandler} id="museum_fee" name="museum_fee" autoComplete='off' placeholder='Entry fee' />
            </div>
            <div className="inputGroup">
                <button type="submit">ADD MUSEUM</button>
            </div>
        </form>
    </div>
  )
}

export default Add