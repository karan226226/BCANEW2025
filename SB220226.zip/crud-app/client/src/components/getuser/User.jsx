import React, { useEffect, useState } from 'react';
import axios from 'axios';
import toast from 'react-hot-toast';
import './user.css';
import { Link } from 'react-router-dom';

const User = () => {
  const [museums, setMuseums] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const response = await axios.get('http://localhost:8000/api/getall');
      setMuseums(response.data);
    };
    fetchData();
  }, []);

  const deleteUser = async (museumId) => {
    await axios
      .delete(`http://localhost:8000/api/delete/${museumId}`)
      .then((response) => {
        setMuseums((prevMuseums) =>
          prevMuseums.filter((museum) => museum._id !== museumId)
        );
        toast.success(response.data.msg, { position: 'top-right' });
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <div className="museumPageContainer">
      <div className="museumContainer">
        <Link to={'/add'} className="addButton">
          Add Museum
        </Link>
        <div className="museumGrid">
          {museums.map((museum, index) => (
            <div key={museum._id} className="museumCard">
              <div className="museumHeader">
                <h3>{museum.museum_name}</h3>
                <span className="museumFee">${museum.museum_fee}</span>
              </div>
              <div className="museumDetails">
                <p>
                  <strong>Location:</strong> {museum.location}
                </p>
                <p>
                  <strong>Type:</strong> {museum.museum_type}
                </p>
              </div>
              <div className="actionButtons">
                <button onClick={() => deleteUser(museum._id)}>
                  <i className="fa-solid fa-trash"></i> Delete
                </button>
                <Link to={`/edit/${museum._id}`}>
                  <i className="fa-solid fa-pen-to-square"></i> Edit
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default User;