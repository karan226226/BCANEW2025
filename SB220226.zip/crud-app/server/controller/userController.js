import Museum from "../model/userModel.js";

export const create = async(req, res) => {
    try {
        const museumData = new Museum(req.body);
        if(!museumData){
            return res.status(404).json({msg: "Museum data not found"});
        }
        await museumData.save();
        res.status(200).json({msg: "Museum created successfully"});
    } catch (error) {
        res.status(500).json({error: error});
    }
}

export const getAll = async(req, res) => {
    try {
        const museumData = await Museum.find();
        if(!museumData){
            return res.status(404).json({msg: "Museum data not found"});
        }
        res.status(200).json(museumData);
    } catch (error) {
        res.status(500).json({error: error});
    }
}

export const getOne = async(req, res) => {
    try {
        const id = req.params.id;
        const museumExist = await Museum.findById(id);
        if(!museumExist){
            return res.status(404).json({msg: "Museum not found"});
        }
        res.status(200).json(museumExist);
    } catch (error) {
        res.status(500).json({error: error});
    }
}

export const update = async(req, res) => {
    try {
        const id = req.params.id;
        const museumExist = await Museum.findById(id);
        if(!museumExist){
            return res.status(401).json({msg: "Museum not found"});
        }

        const updatedData = await Museum.findByIdAndUpdate(id, req.body, {new: true});
        res.status(200).json({msg: "Museum updated successfully"});
    } catch (error) {
        res.status(500).json({error: error});
    }
}

export const deleteUser = async(req, res) => {
    try {
        const id = req.params.id;
        const museumExist = await Museum.findById(id);
        if(!museumExist){
            return res.status(404).json({msg: "Museum does not exist"});
        }
        await Museum.findByIdAndDelete(id);
        res.status(200).json({msg: "Museum deleted successfully"});
    } catch (error) {
        res.status(500).json({error: error});
    }
}