import mongoose from "mongoose";

const museumSchema = new mongoose.Schema({
    museum_name: {
        type: String,
        required: true
    },
    location: {
        type: String,
        required: true
    },
    museum_type: {
        type: String,
        required: true
    },
    museum_fee: {
        type: Number,
        required: true
    }
})

export default mongoose.model("Museum", museumSchema);